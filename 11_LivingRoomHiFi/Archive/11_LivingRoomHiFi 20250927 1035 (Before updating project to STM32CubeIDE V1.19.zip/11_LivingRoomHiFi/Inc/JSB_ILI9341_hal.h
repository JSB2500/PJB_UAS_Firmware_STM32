#ifndef __JSB_ILI9341_HAL_H
#define __JSB_ILI9341_HAL_H

#include "stm32f7xx_hal.h"
#include "main.h"

#endif
