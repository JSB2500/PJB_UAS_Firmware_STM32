#ifndef GO_H_
#define GO_H_

void Go();
void ProcessAudio(AudioBufferHalf_t AudioBufferHalf);

#endif
