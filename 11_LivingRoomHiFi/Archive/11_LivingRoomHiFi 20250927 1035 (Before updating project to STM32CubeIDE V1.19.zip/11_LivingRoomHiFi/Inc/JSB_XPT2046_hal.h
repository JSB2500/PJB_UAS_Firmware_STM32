#ifndef __JSB_XPT2046_HAL_H
#define __JSB_XPT2046_HAL_H

#include "stm32f7xx_hal.h"

#endif
